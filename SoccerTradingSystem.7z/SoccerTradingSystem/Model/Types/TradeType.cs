﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoccerTradingSystem.Model.Types
{
    class TradeType
    {
        public static String LEASE = "LEASE";
        public static String BELONG = "BELONG";
    }
}
