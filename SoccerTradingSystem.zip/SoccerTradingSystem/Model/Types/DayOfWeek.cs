﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoccerTradingSystem.Model.Types
{
    class DayOfWeek
    {
        public static String MON = "MON";
        public static String TUE = "TUE";
        public static String WED = "WED";
        public static String THU = "THU";
        public static String FRI = "FRI";
        public static String SAT = "SAT";
        public static String SUN = "SUN";
    }
}
