﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoccerTradingSystem.Model
{
    class Address
    {
        public String country;
        public String state;
        public String city;
        public String number;
        public String zipcode;
    }
}
